
    public class Juego extends Thread{
        
        public void run(){
            JuegoBolitas objJuego = new JuegoBolitas();
            objJuego.iniciar();

        }
    }
