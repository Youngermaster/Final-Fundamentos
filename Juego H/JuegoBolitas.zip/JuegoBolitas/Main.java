public class Main{

    public static void main(String[] args){

        ProgramaX programaX = new ProgramaX();
        programaX.ejecutar();

    }
}